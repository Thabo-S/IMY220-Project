// import React, { useState, useEffect } from "react";
// import { Link } from "react-router-dom";
// import Feed from "../components/Feed";
// import SearchInput from "../components/SearchInput";
// import Navbar from "../components/Navbar";
// import Filters from "../components/filters"
// import Footer from "../components/Footer";
// import PalmTree from "../components/PalmTree";

// const Home = () => {
//     const [searchTerm, setSearchTerm] = useState("");
//     const [currentUser, setCurrentUser] = useState(null);
//     const [localActivity, setLocalActivity] = useState([]);
//     const [globalActivity, setGlobalActivity] = useState([]);
//     const [isLoading, setIsLoading] = useState(true);

//     useEffect(() => {
//         const storedUserData = localStorage.getItem("user");
//         let storedUser = null;
//         if (storedUserData) {
//             try {
//                 storedUser = JSON.parse(storedUserData);
//             } catch (error) {
//                 console.error('Error parsing user data:', error);
//             }
//         }
//         setCurrentUser(storedUser);

//         const fetchData = async () => {
//             setIsLoading(true);
//             await fetchGlobalActivity();
//             if (storedUser?.id) {
//                 await fetchLocalActivity(storedUser.id);
//             }
//             setIsLoading(false);
//         };
//         fetchData();
//     }, []);

//     const fetchLocalActivity = async (userId) => {
//         try {
//             const response = await fetch(`/api/activity/local/${userId}`);
//             if (!response.ok) throw new Error('Failed to fetch local activity');
//             const data = await response.json();
//             setLocalActivity(data);
//         } catch (error) {
//             console.error('Error fetching local activity:', error);
//         }
//     };

//     const fetchGlobalActivity = async () => {
//         try {
//             const response = await fetch('/api/activity/global');
//             if (!response.ok) throw new Error('Failed to fetch global activity');
//             const data = await response.json();
//             setGlobalActivity(data);
//         } catch (error) {
//             console.error('Error fetching global activity:', error);
//         }
//     };

//     if (isLoading) {
//         return <div>Loading...</div>;
//     }

//     return (
//         <>
//             <Navbar />
//             <div className="home-page">
//                 <h1>Welcome back, {currentUser ? currentUser.name : "User"}</h1>

//                 <SearchInput
//                     value={searchTerm}
//                     onChange={setSearchTerm}
//                     placeholder="Search projects..."
//                 />

//                 <Filters />

//                 <div className="feeds-container">
//                     <Feed
//                         title="Local Activity"
//                         activities={localActivity}
//                         type="local"
//                     />
//                     <Feed
//                         title="Global Activity"
//                         activities={globalActivity}
//                         type="global"
//                     />
//                 </div>
//             </div>
//             <PalmTree />
//             <Footer />
//         </>
//     );
// };

// export default Home;

import React, { useState, useEffect } from "react";
import Feed from "../components/Feed";
import SearchInput from "../components/SearchInput";
import Navbar from "../components/Navbar";
import Filters from "../components/filters";
import Footer from "../components/Footer";
import PalmTree from "../components/PalmTree";

const Home = () => {
    const [searchTerm, setSearchTerm] = useState("");
    const [currentUser, setCurrentUser] = useState(null);
    const [localActivity, setLocalActivity] = useState([]);
    const [globalActivity, setGlobalActivity] = useState([]);
    const [isLoading, setIsLoading] = useState(true);

    useEffect(() => {
        const storedUserData = localStorage.getItem("user");
        let storedUser = null;
        if (storedUserData) {
            try {
                storedUser = JSON.parse(storedUserData);
            } catch (error) {
                console.error('Error parsing user data:', error);
            }
        }
        setCurrentUser(storedUser);

        const fetchData = async () => {
            setIsLoading(true);
            await fetchGlobalActivity();
            if (storedUser?.id) {
                await fetchLocalActivity(storedUser.id);
            }
            setIsLoading(false);
        };
        fetchData();
    }, []);

    const fetchLocalActivity = async (userId) => {
        try {
            const response = await fetch(`/api/activity/local/${userId}`);
            if (!response.ok) throw new Error('Failed to fetch local activity');
            const data = await response.json();
            console.log('Local Activity Data:', data); // Debug log
            // Ensure each activity has a project object if missing
            const formattedData = data.map(activity => ({
                ...activity,
                project: activity.project || { id: activity.id, name: activity.name || 'Unnamed' }
            }));
            setLocalActivity(formattedData);
        } catch (error) {
            console.error('Error fetching local activity:', error);
        }
    };

    const fetchGlobalActivity = async () => {
        try {
            const response = await fetch('/api/activity/global');
            if (!response.ok) throw new Error('Failed to fetch global activity');
            const data = await response.json();
            console.log('Global Activity Data:', data); // Debug log
            setGlobalActivity(data);
        } catch (error) {
            console.error('Error fetching global activity:', error);
        }
    };

    if (isLoading) {
        return <div>Loading...</div>;
    }

    return (
        <>
            <Navbar />
            <div className="home-page">
                <h1>Welcome back, {currentUser ? currentUser.name : "User"}</h1>
                
                <SearchInput 
                    value={searchTerm} 
                    onChange={setSearchTerm} 
                    placeholder="Search projects..." 
                />

                <Filters />
          
                <div className="feeds-container">
                    <Feed 
                        title="Local Activity" 
                        activities={localActivity} 
                        type="local"
                    />
                    <Feed 
                        title="Global Activity" 
                        activities={globalActivity} 
                        type="global"
                    />
                </div>
            </div>
            <PalmTree />
            <Footer />
        </>
    );
};

export default Home;