import React from "react";
import { Link } from "react-router-dom";

const ActivityItem = ({ activity }) => {
    const renderLabel = () => {
        switch (activity.type) {
            case "checkin":
                return "Check-in";
            case "update":
                return "Update";
            default:
                return "System";
        }
    };

    // Safely access project.id with a fallback
    const projectId = activity.project?.id || (activity.id ? `/activity/${activity.id}` : '#');

    // Safely access user data with fallbacks
    const userName = activity.user?.name || 'Unknown User';
    const projectName = activity.project?.name || 'Unnamed Activity';

    return (
        <Link to={projectId} className="activity-link">
            <div className="activity-item">
                <div className="activity-icon">
                    {renderLabel()}
                </div>
                <div className="activity-content">
                    <p>
                        <strong>{userName}</strong> {activity.type}{" "}
                        {projectName}
                    </p>
                    <small>{activity.time}</small>
                </div>
            </div>
        </Link>
    );
};

export default ActivityItem;