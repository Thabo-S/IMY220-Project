import React, { useState, useEffect } from "react";

const FriendRequestButton = ({ targetUserId, currentUserId, onUpdate }) => {
    const [status, setStatus] = useState('none');

    useEffect(() => {
        const fetchStatus = async () => {
            try {
                const friendsResponse = await fetch(`/api/friends/${currentUserId}`);
                const friendIds = await friendsResponse.json();
                if (friendIds.includes(targetUserId)) {
                    setStatus('friends');
                    return;
                }

                const requestsResponse = await fetch(`/api/friend-requests/pending/${currentUserId}`);
                const { incoming, outgoing } = await requestsResponse.json();

                if (outgoing.some(req => req.to === targetUserId)) {
                    setStatus('pending_sent');
                } else if (incoming.some(req => req.from === targetUserId)) {
                    setStatus('pending_received');
                } else {
                    setStatus('none');
                }
            } catch (error) {
                console.error('Error fetching friend status:', error);
            }
        };
        if (targetUserId !== currentUserId) {
            fetchStatus();
        }
    }, [targetUserId, currentUserId]);

    const handleSendRequest = async () => {
        try {
            const response = await fetch('/api/friend-request', {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({ from: currentUserId, to: targetUserId }),
            });
            if (!response.ok) throw new Error('Failed to send request');
            setStatus('pending_sent');
            if (onUpdate) onUpdate();
        } catch (error) {
            console.error('Error sending request:', error);
        }
    };

    const handleCancelRequest = async () => {
        try {
            const response = await fetch('/api/friend-request/cancel', {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({ from: currentUserId, to: targetUserId }),
            });
            if (!response.ok) throw new Error('Failed to cancel request');
            setStatus('none');
            if (onUpdate) onUpdate();
        } catch (error) {
            console.error('Error cancelling request:', error);
        }
    };

    const handleAccept = async () => {
        try {
            const response = await fetch('/api/friend-request/accept', {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({ from: targetUserId, to: currentUserId }),
            });
            if (!response.ok) throw new Error('Failed to accept request');
            setStatus('friends');
            if (onUpdate) onUpdate();
        } catch (error) {
            console.error('Error accepting request:', error);
        }
    };

    const handleReject = async () => {
        try {
            const response = await fetch('/api/friend-request/reject', {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({ from: targetUserId, to: currentUserId }),
            });
            if (!response.ok) throw new Error('Failed to reject request');
            setStatus('none');
            if (onUpdate) onUpdate();
        } catch (error) {
            console.error('Error rejecting request:', error);
        }
    };

    const handleRemoveFriend = async () => {
        try {
            const response = await fetch('/api/friends', {
                method: 'DELETE',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({ userId: currentUserId, friendId: targetUserId }),
            });
            if (!response.ok) throw new Error('Failed to remove friend');
            setStatus('none');
            if (onUpdate) onUpdate();
        } catch (error) {
            console.error('Error removing friend:', error);
        }
    };

    if (targetUserId === currentUserId) return null;

    return (
        <div className="friend-request-button">
            {status === 'none' && (
                <button onClick={handleSendRequest}>Add Friend</button>
            )}
            {status === 'pending_sent' && (
                <>
                    <span>Request Sent</span>
                    <button onClick={handleCancelRequest}>Cancel</button>
                </>
            )}
            {status === 'pending_received' && (
                <>
                    <button onClick={handleAccept}>Accept</button>
                    <button onClick={handleReject}>Reject</button>
                </>
            )}
            {status === 'friends' && (
                <>
                    <span>Friends</span>
                    <button onClick={handleRemoveFriend}>Remove</button>
                </>
            )}
        </div>
    );
};

export default FriendRequestButton;